# Current best physical B artwork

- Resolution: 1800 px; 512 nails; 93,281 independent chord placements.
- Sampled physical MSE: q128 = 642.346698482641; q512 = 642.345436145087.
- Renderer: deterministic opaque capsules, box-average then square; these are sampled values, not a continuous certificate.
- Construction CSV is bottom-to-top. Place each separate strand at both endpoint nails and cut it before the next row.
- The package includes the research capture, source/masks, validation, preview, and explicit construction CSV/manifest.
