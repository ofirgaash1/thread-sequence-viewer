# Residual-diffusion seed artwork

- Sampled physical MSE: q128 = 764.3652386331033; q512 = 764.362005294185.
- Resolution: 1800 px; 512 nails; 90,682 thread placements.
- Initializer: CPU Unified Continuous K13, tau 1000, residual diffusion strength 1; color relaxation off.
- The build CSV is bottom-to-top. Each row is an independent chord: tie at both endpoint nails, then cut before the next row.
- Package includes the exact sequence, source/masks, seed provenance, same-renderer preview, and explicit construction export.
